$(function () {
  $(".img2").click(function () {
    alert("logo clicked");
  });
});
