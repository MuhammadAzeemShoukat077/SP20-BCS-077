import React, { useCallback } from "react";
import { useState } from "react";
import data from "./Components/Data/Data";
import Header from "./Components/Header";
import { BrowserRouter as Router } from "react-router-dom";
import Routes from "./Components/Routes";
import { AuthContext } from "./auth";
//import Login from "./Components/Login";

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userId, setUserId] = useState(false);

  //useEffect can also be used here.
  const login = useCallback((id) => {
    setIsLoggedIn(true);
    setUserId(id);
    // console.log(id, "id");
  }, []);

  const logout = useCallback(() => {
    setIsLoggedIn(false);
    setUserId(null);
  }, []);

  const { productItems } = data;
  const [CartItems, setCartItems] = useState([]);

  const HandleProductList = (product) => {
    const ProductExist = CartItems.find((item) => item.id === product.id);
    console.log(ProductExist, "oops");
    if (ProductExist) {
      setCartItems(
        CartItems.map((item) =>
          item.id === product.id
            ? { ...ProductExist, quantity: ProductExist.quantity + 1 }
            : item
        )
      );
    } else {
      setCartItems([...CartItems, { ...product, quantity: 1 }]);
    }
  };
  const HandleRemoveList = (product) => {
    const ProductExist = CartItems.find((item) => item.id === product.id);
    if (ProductExist.quantity === 1) {
      setCartItems(CartItems.filter((item) => item.id !== product.id));
    } else {
      setCartItems(
        CartItems.map((item) =>
          item.id === product.id
            ? { ...ProductExist, quantity: ProductExist.quantity - 1 }
            : item
        )
      );
    }
  };
  const HandleCartClear = () => {
    setCartItems([]);
  };
  return (
    <AuthContext.Provider
      value={{
        isLoggedIn: isLoggedIn,
        userId: userId,
        login: login,
        logout: logout,
      }}
    >
      <Router>
        <Header CartItems={CartItems} />

        <Routes
          productItems={productItems}
          CartItems={CartItems}
          HandleProductList={HandleProductList}
          HandleRemoveList={HandleRemoveList}
          HandleCartClear={HandleCartClear}
        />
      </Router>
    </AuthContext.Provider>
  );
};
export default App;
