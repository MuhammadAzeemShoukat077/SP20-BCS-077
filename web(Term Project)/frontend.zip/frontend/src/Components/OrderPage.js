import React, { useState, useContext, useEffect } from "react";
import "./Css/Order.css";
import "./Css/placeorder.css";
import { AuthContext } from "../auth";
import { useHistory } from "react-router-dom";

const OrderPage = ({ CartItems, HandleCartClear }) => {
  const history = useHistory();
  const context = useContext(AuthContext);
  const [email, setEmail] = useState();
  const [address1, setAddress1] = useState();
  const [address2, setAddress2] = useState();
  const [city, setCity] = useState();
  const [state, setState] = useState();
  const [zip, setZip] = useState();

  useEffect(() => {
    const getUser = async () => {
      if (!context.isLoggedIn) {
        return;
      }
      const res = await fetch(
        `http://localhost:8000/user/getbyid/${context.userId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      const data = await res.json();
      //console.log(data)
      if (data) {
        setEmail(data.user.email);
        setAddress1(data.user.address);
        setCity(data.user.city);
        setState(data.user.state);
        setZip(data.user.zip);
      }
    };

    getUser();
  }, [context.userId, context.isLoggedIn]);

  const addOrder = async () => {
    //console.log(CartItems)
    let order = CartItems.map((e, index) => ({
      name: e.name,
      quantity: e.quantity,
      price: e.price,
    }));

    const res = await fetch("http://localhost:8000/order/add", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        order: order,
        uid: context.userId,
      }),
    });
    const data = await res.json();
    if (res.status === 400 || !data) {
      window.alert("Failed");
    } else {
      window.alert("Order Confirmed");
      HandleCartClear();
      history.push("/");
    }

    console.log(order);
  };

  const formSubmit = async (e) => {
    e.preventDefault();
    //console.log(email, address1, address2, city, state, zip)

    const res = await fetch("http://localhost:5000/user/update", {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        uid: context.userId,
        // name: name,
        // password: password,
      }),
    });

    const data = await res.json();
    console.log(data);
    if (res.status === 400 || !data) {
      window.alert("Failed");
    } else {
      addOrder();
      history.push("/login");
    }
  };

  return (
    <div className="container  back">
      <form onSubmit={formSubmit} class="row g-4">
        <div className="row ms-1">
          <h1>PLace your order</h1>
        </div>
        <div class="col-md-6 ">
          <label for="inputEmail4" class="form-label">
            Email
          </label>
          <input
            type="email"
            class="form-control"
            id="inputEmail4"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div class="col-6">
          <label for="inputAddress" class="form-label">
            Address
          </label>
          <input
            type="text"
            class="form-control"
            id="inputAddress"
            placeholder="1234 Main St"
            value={address1}
            onChange={(e) => setAddress1(e.target.value)}
          />
        </div>
        <div class="col-6">
          <label for="inputAddress2" class="form-label">
            Address 2
          </label>
          <input
            type="text"
            class="form-control"
            id="inputAddress2"
            placeholder="Apartment, studio, or floor"
            value={address2}
            onChange={(e) => setAddress2(e.target.value)}
          />
        </div>
        <div class="col-md-6">
          <label for="inputCity" class="form-label">
            City
          </label>
          <input
            type="text"
            class="form-control"
            id="inputCity"
            value={city}
            onChange={(e) => setCity(e.target.value)}
          />
        </div>
        <div class="col-md-4">
          <label for="inputState" class="form-label">
            State
          </label>
          <select
            id="inputState"
            class="form-select"
            value={state}
            onChange={(e) => setState(e.target.value)}
          >
            <option value="null" selected>
              Choose...
            </option>
            <option value="Faisalabad">Faisalabad</option>
            <option value="Lahore">Lahore</option>
            <option value="Islamabad">Islamabad</option>
            <option value="Karachi">Karachi</option>
          </select>
        </div>
        <div class="col-md-2">
          <label for="inputZip" class="form-label">
            Zip
          </label>
          <input
            type="text"
            class="form-control"
            id="inputZip"
            value={zip}
            onChange={(e) => setZip(e.target.value)}
          />
        </div>
        <div class="col-12">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="gridCheck" />
            <label class="form-check-label" for="gridCheck">
              Check me out
            </label>
          </div>
        </div>
        <div class="col-12">
          <button type="submit" class="btn btn-primary">
            Order Place
          </button>
        </div>
      </form>
    </div>
  );
};

export default OrderPage;
