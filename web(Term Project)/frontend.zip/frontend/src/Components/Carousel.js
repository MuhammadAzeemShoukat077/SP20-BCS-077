import React from "react";
const Carousel = () => {
  return (
    <div className="carousel">
      <div className="mySlides fade">
        <div className="numbertext">1 / 3</div>
        <img src="./pics/drinks.jpg" style="width:100%"></img>
      </div>

      <div className="mySlides fade">
        <div className="numbertext">2 / 3</div>
        <img src="./fastfood.png" style="width:100%"></img>
      </div>

      <div className="mySlides fade">
        <div className="numbertext">3 / 3</div>
        <img src="./pics/nugget.jpg" style="width:100%"></img>
      </div>

      <a className="prev" onclick="plusSlides(-1)">
        ❮
      </a>
      <a className="next" onclick="plusSlides(1)">
        ❯
      </a>

      <div style="text-align:center">
        <span className="dot" onclick="currentSlide(1)"></span>
        <span className="dot" onclick="currentSlide(2)"></span>
        <span className="dot" onclick="currentSlide(3)"></span>
      </div>
    </div>
  );
};

export default Carousel;
