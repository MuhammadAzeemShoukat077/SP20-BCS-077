import React, { useState } from "react";
import { Link, useHistory } from "react-router-dom";
import "./Css/index.css";

const Login = () => {
  const history = useHistory();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState();

  const SubmitForm = async (e) => {
    e.preventDefault();
    const res = await fetch("http://localhost:8000/user/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: name,
        password: password,
        email: email,
      }),
    });
    if (res.ok) {
      setUser(res);
    }
    const data = await res.json();
    console.log("signup", data);
    if (res.status === 400 || !data) {
      window.alert("invalid crediants");
    } else {
      window.alert("successfully Register");
      history.push("/login");
    }
  };

  return (
    <div className="back">
      <div className="container ">
        <div className="row">
          <div className="">
            <form>
              <h1>Snack Pedia</h1>
              {/* <img src="./pics/logo2.png" width="90%" height="150%"></img> */}
              <div className="">
                <label
                  for="exampleInputEmail1"
                  className="form-label"
                  style={{ color: "yellow" }}
                >
                  UserName
                </label>
                <input
                  type="UserName"
                  className="form-control"
                  id="exampleInputEmail1"
                  aria-describedby="emailHelp"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>

              <div className="mb-3">
                <label for="exampleInputEmail1" className="form-label">
                  Email address
                </label>
                <input
                  type="email"
                  className="form-control"
                  id="exampleInputEmail1"
                  aria-describedby="emailHelp"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <div
                  id="emailHelp"
                  className="form-text"
                  style={{ color: "red" }}
                >
                  We'll never share your email with anyone else.
                </div>
              </div>
              <div className="mb-3">
                <label for="exampleInputPassword1" className="form-label">
                  Password
                </label>
                <input
                  type="password"
                  className="form-control"
                  id="exampleInputPassword1"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div className="mb-3 form-check">
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="exampleCheck1"
                />
                <label className="form-check-label" for="exampleCheck1">
                  Check me out
                </label>
              </div>
              <Link
                className="btn btn-primary"
                onClick={SubmitForm}
                to={user ? "/" : "/SignUp"}
              >
                Submit
              </Link>
              <Link className="links" to="/login" style={{ color: "blue" }}>
                already have an acount ?Login
              </Link>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
