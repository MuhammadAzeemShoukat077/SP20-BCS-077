import React, { useContext } from "react";
import { Link, useHistory } from "react-router-dom";
//import "./Css/App.css";
// import "bootstrap/dist/css/bootstrap.min.css";
import "./Css/Header.css";
import { AuthContext } from "../auth";

const Header = ({ CartItems }) => {
  const history = useHistory();
  const context = useContext(AuthContext);

  const logout = () => {
    context.logout();
    history.push("/");
  };

  return (
    <div className="Header-container">
      <h1>Snack Pedia</h1>
      {/* <img className="logo" src="./pics/logo2.png" alt=""></img> */}

      <ul className="links-container">
        <li className="links">
          <Link className="" to="/">
            Home
          </Link>
        </li>

        <li className="links">
          <Link className="" to={"/contact us"}>
            Contact US
          </Link>
        </li>
        <li className="links">
          <Link className="" to="/details">
            Details
          </Link>
        </li>
        {!context.isLoggedIn ? (
          <>
            <li className="links">
              <Link className="" to="/login">
                Login
              </Link>
            </li>
            <li className="links">
              <Link className="" to="/SignUp">
                SignUp
              </Link>
            </li>
          </>
        ) : (
          <li className="links">
            <button
              className=""
              onClick={() => logout()}
              style={{
                backgroundColor: "transparent",
                outline: "none",
                border: "none",
              }}
            >
              Logout
            </button>
          </li>
        )}
      </ul>
      <Link to="/cart" className="">
        <button type="button" class="btn btn-danger ">
          <i class="fas fa-shopping-cart">Cart </i>
          <span className="cart-icon">
            {CartItems.length === 0 ? "" : CartItems.length}
          </span>
        </button>
      </Link>
    </div>
  );
};
export default Header;
