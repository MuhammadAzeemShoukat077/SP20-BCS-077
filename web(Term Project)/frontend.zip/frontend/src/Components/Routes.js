import React from "react";
import { Route, Switch } from "react-router-dom";
import Products from "./Products";
import Cart from "./Cart";
import Details from "./Details";
import Signup from "./SignUp";
import Login from "./Login";
import OrderPage from "./OrderPage";
function Routes({
  productItems,
  CartItems,
  HandleProductList,
  HandleRemoveList,
  HandleCartClear,
}) {
  return (
    <Switch>
      <Route path="/Login" exact>
        <Login />
      </Route>
      <Route path="/SignUp" exact>
        <Signup />
      </Route>
      {/* <Route path="/OrderPage" exact>
        <OrderPage CartItems={CartItems} HandleCartClear={HandleCartClear} />
      </Route> */}
      <Route path="/" exact>
        <Products
          productItems={productItems}
          HandleProductList={HandleProductList}
        />
      </Route>

      {/* <Route path="/cart" exact>
        <Cart
          CartItems={CartItems}
          HandleProductList={HandleProductList}
          HandleRemoveList={HandleRemoveList}
          HandleCartClear={HandleCartClear}
        />
      </Route> */}

      <Route path="/Details" exact>
        <Details />
      </Route>
    </Switch>
  );
}

export default Routes;
