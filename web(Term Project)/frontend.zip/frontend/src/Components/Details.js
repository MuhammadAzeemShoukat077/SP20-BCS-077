import React from "react";
import { Button, Container, Row } from "react-bootstrap";
// import "./Css/LandingPage.css";
const Details = () => {
  return (
    <div className="main">
      <div className="container">
        <Row>
          <div className="text mt-5 mt-sm-4 mt-md-3">
            <div>
              <h3 className="title">Welcome!</h3>
            </div>
            <div className="containerbutton">
              <a href="/login">
                <Button size="md" className="landingbutton" variant="primary">
                  Login
                </Button>
              </a>
              <a href="/SignUp">
                <Button
                  size="md"
                  className="landingbutton"
                  variant="outline-primary"
                >
                  SignUp
                </Button>
              </a>
            </div>
          </div>
        </Row>
      </div>
    </div>
  );
};

export default Details;
