import React, { useState, useContext } from "react";
import "./Css/Header.css";
import "./Css/SignUp.css";
import "./Css/Login.css";
import { Link, useHistory } from "react-router-dom";
import { AuthContext } from "../auth";
import axios from "axios";

const Login = () => {
  const context = useContext(AuthContext);
  const history = useHistory();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState();
  const loginUser = async (e) => {
    e.preventDefault();

    if (!email || !password) {
      window.alert("Please Enter Email or Password");
      return;
    }

    // const res = await fetch(
    //   `http://localhost:5000/user/get/${email}/${password}`,
    //   {
    //     method: "GET",
    //     headers: {
    //       "Content-Type": "application/json",
    //     },
    //   }
    // );
    // const data = await res.json();
    // const data = await axios.post(
    //   `http://localhost:8000/user/${email}/${password}`,
    //   {
    //     headers: {
    //       "Content-Type": "application/json",
    //     },
    //   }
    // );
    // console.log("data =>", data);
    // setUser(data);

    const data = axios("`http://localhost:8000/user", {
      method: "post",
      timeout: 1000,
      headers: {
        "Content-Type": "application/json",
      },
      data: {
        email: email,
        password: password,
      },
    });
    console.log("data =>", data);
    //setUser(data);

    // const data = await res.json();
    if (data.status !== 200 || !data) {
      window.alert("invalid credentials or user already exists");
    } else {
      //window.alert("successfully login");
      context.login(data._id);
      history.push("/");
    }
  };
  return (
    <div className="loginform">
      <form method="POST">
        <div className="img-container">
          {/* // <img src="./pics/logo2.png"></img> */}
          <h1>Snack Pedia</h1>
        </div>
        <div className="">
          <label for="exampleInputEmail1" className="form-label">
            Email address
          </label>
          <input
            type="email"
            className="form-control"
            autoSave="false"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <div id="emailHelp" className="form-text">
            We'll never share your email with anyone else.
          </div>
        </div>
        <div className="">
          <label for="exampleInputPassword1" className="form-label">
            Password
          </label>
          <input
            type="password"
            className="form-control"
            id="exampleInputPassword1"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        {
          <div className="mb-3">
            <input
              type="checkbox"
              className="form-check-input"
              id="exampleCheck1"
            />
            <label className="form-check-label" for="exampleCheck1">
              Check me out
            </label>
          </div>
        }
        <Link
          className="btn btn-primary"
          onClick={loginUser}
          to={user ? "/" : "/login"}
        >
          Submit
        </Link>
        <Link className="links" to="/SignUp" style={{ color: "blue" }}>
          Don't have an acount ?SignUp
        </Link>
      </form>
    </div>
  );
};

export default Login;
