import SignUp from "./SignUp";
import { SignFormSuccess } from "./SignFormSuccess";
import React, { useState } from "react";

export const Form = ({ CartItems }) => {
  const submitForm = () => {
    setFormIsSubmitted(true);
  };
  const [formIsSubmitted, setFormIsSubmitted] = useState(false);
  return (
    <div>
      {!formIsSubmitted ? (
        <SignUp submitForm={submitForm} CartItems={CartItems} />
      ) : (
        <SignFormSuccess />
      )}
    </div>
  );
};
