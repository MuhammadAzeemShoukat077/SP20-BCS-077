const data = {
  productItems: [
    {
      id: "1",
      name: "Burger",
      price: 2,
      image: "./pics/card.jpg",
    },
    {
      id: "2",
      name: "coffee",
      price: 1,
      image: "./pics/card2.jpg",
    },
    {
      id: "3",
      name: "pizza",
      price: 5,
      image: "./pics/card.jpg",
    },
    {
      id: "4",
      name: "coffee",
      price: 2,
      image: "./pics/card2.jpg",
    },
    {
      id: "5",
      name: "pizza",
      price: 10,
      image: "./pics/card.jpg",
    },
    {
      id: "6",
      name: "pizza",
      price: 10,
      image: "./pics/card2.jpg",
    },
    {
      id: "7",
      name: "pizza",
      price: 10,
      image: "./pics/card.jpg",
    },
    {
      id: "8",
      name: "pizza",
      price: 10,
      image: "./pics/card2.jpg",
    },
  ],
};
export default data;
