import React, { useContext, useState } from "react";
import "./Css/Products.css";
import { Link, useHistory } from "react-router-dom";
import { AuthContext } from "../auth";

function Products({ productItems, HandleProductList }) {
  // const history = useHistory();
  const context = useContext(AuthContext);

  // let slideIndex = 1;
  // showSlides(slideIndex);

  // function plusSlides(n) {
  //   showSlides((slideIndex += n));
  // }

  // function currentSlide(n) {
  //   showSlides((slideIndex = n));
  // }

  // function showSlides(n) {
  //   let i;
  //   let slides = document.getElementsByClassName("mySlides");
  //   let dots = document.getElementsByClassName("dot");
  //   if (n > slides.length) {
  //     slideIndex = 1;
  //   }
  //   if (n < 1) {
  //     slideIndex = slides.length;
  //   }
  //   for (i = 0; i < slides.length; i++) {
  //     slides[i].style.display = "none";
  //   }
  //   for (i = 0; i < dots.length; i++) {
  //     dots[i].className = dots[i].className.replace(" active", "");
  //   }
  //   slides[slideIndex - 1].style.display = "block";
  //   dots[slideIndex - 1].className += " active";
  // }

  return (
    //<div className="container-fluid">
    /* {images.map((data) => ( */

    /* <div className="row">
          <div className="col-12">
            <div
              id="carouselExampleCaptions"
              class="carousel slide"
              data-bs-ride="carousel"
            >
              <div class="carousel-indicators">
                <button
                  type="button"
                  data-bs-target="#carouselExampleCaptions"
                  data-bs-slide-to="0"
                  class="active"
                  aria-current="true"
                  aria-label="Slide 1"
                ></button>
                <button
                  type="button"
                  data-bs-target="#carouselExampleCaptions"
                  data-bs-slide-to="1"
                  aria-label="Slide 2"
                ></button>
                <button
                  type="button"
                  data-bs-target="#carouselExampleCaptions"
                  data-bs-slide-to="2"
                  aria-label="Slide 3"
                ></button>
              </div>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img
                    src="./pics/crouser.jpg"
                    class="d-block w-100"
                    alt="..."
                    style={{ height: "400px" }}
                  />
                  <div class="carousel-caption d-none d-md-block">
                    <h5>First slide label</h5>
                    <p>
                      Some representative placeholder content for the first
                      slide.
                    </p>
                  </div>
                </div>
                <div class="carousel-item">
                  <img
                    src="./pics/crouser1.jpg"
                    class="d-block w-100"
                    alt="..."
                    style={{ height: "400px" }}
                  />
                  <div class="carousel-caption d-none d-md-block">
                    <h5>Second slide label</h5>
                    <p>
                      Some representative placeholder content for the second
                      slide.
                    </p>
                  </div>
                </div>
                <div class="carousel-item">
                  <img
                    src="./pics/crouser3.jpg"
                    class="d-block w-100"
                    alt="..."
                    style={{ height: "400px" }}
                  />
                  <div class="carousel-caption d-none d-md-block">
                    <h5>Third slide label</h5>
                    <p>
                      Some representative placeholder content for the third
                      slide.
                    </p>
                  </div>
                </div>
              </div>
              <button
                class="carousel-control-prev"
                type="button"
                data-bs-target="#carouselExampleCaptions"
                data-bs-slide="prev"
              >
                <span
                  class="carousel-control-prev-icon"
                  aria-hidden="true"
                ></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button
                class="carousel-control-next"
                type="button"
                data-bs-target="#carouselExampleCaptions"
                data-bs-slide="next"
              >
                <span
                  class="carousel-control-next-icon"
                  aria-hidden="true"
                ></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </div>
        </div> */
    /* // ))} */
    /* //card ........................................... */

    // <hr className="bold" style={{ fontWeight: "bold" }} />
    // <div className="carousel">
    //   <div className="mySlides fade">
    //     <div className="numbertext">1 / 3</div>
    //     <img src="./pics/drinks.jpg" style="width:100%"></img>
    //   </div>

    //   <div className="mySlides fade">
    //     <div className="numbertext">2 / 3</div>
    //     <img src="./fastfood.png" style="width:100%"></img>
    //   </div>

    //   <div className="mySlides fade">
    //     <div className="numbertext">3 / 3</div>
    //     <img src="./pics/nugget.jpg" style="width:100%"></img>
    //   </div>

    //   <a className="prev" onclick="plusSlides(-1)">
    //     ❮
    //   </a>
    //   <a className="next" onclick="plusSlides(1)">
    //     ❯
    //   </a>

    //   <div style="text-align:center">
    //     <span className="dot" onclick="currentSlide(1)"></span>
    //     <span className="dot" onclick="currentSlide(2)"></span>
    //     <span className="dot" onclick="currentSlide(3)"></span>
    //   </div>

    <div className="card-container">
      {productItems.map((productItem, index) => (
        <div className="card-container">
          <div className="card" style={{ width: "18rem" }}>
            <div className="inner">
              <img
                class="card-img-top"
                src={productItem.image}
                alt={productItems.name}
              />
            </div>
            <div className="card-body">
              <h3>
                {productItem.name}
                <div className="product-price">${productItem.price}</div>
              </h3>

              <button
                type="button"
                className="btn btn-danger "
                onClick={
                  //  <Link to={"/details"}></Link>

                  context.isLoggedIn ? (
                    () => HandleProductList(productItem)
                  ) : (
                    <Link to={"/details"}></Link>
                  )
                }
              >
                <i class="fas fa-shopping-cart"> Add to Cart</i>
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
    //</div>
    //</>
  );
}

export default Products;

//....................................................................................................
