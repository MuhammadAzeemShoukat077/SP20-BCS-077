import React, { createContext } from "react";
import "./Css/Cart.css";
import { Link } from "react-router-dom";
const Cart = ({
  CartItems,
  HandleRemoveList,
  HandleProductList,
  HandleCartClear,
}) => {
  const First = createContext();
  const TotalPrice = CartItems.reduce(
    (price, item) => price + item.quantity * item.price,
    0
  );
  return (
    <div className="cart-item">
      <div className="cart-header">cart Item</div>
      <div className="cart-clear">
        {CartItems.length >= 1 && (
          <button className="clear-button" onClick={HandleCartClear}>
            Clear Cart
          </button>
        )}
      </div>

      {CartItems.length === 0 && (
        <div className="cart-empty">no items in the cart</div>
      )}
      <div>
        {CartItems.map((item) => (
          <div key={item.id} className="cart-list">
            <img src={item.image} alt={item.name} className="cart-image" />
            <div className="cart-name">{item.name}</div>
            <div className="cart-function">
              <button
                className="cart-add"
                onClick={() => HandleProductList(item)}
              >
                +
              </button>
              <button
                className="cart-remove"
                onClick={() => HandleRemoveList(item)}
              >
                -
              </button>
            </div>
            <div className="cart-Price">
              {item.quantity} * {item.price}
            </div>
          </div>
        ))}
      </div>

      <div className="total-price">
        TotalPrice:
        <div className="Cart-total-price">${TotalPrice}</div>
      </div>
      <Link className="nav-link" to="/OrderPage">
        <div>
          <button className="cart-end">Order Placed</button>
        </div>
      </Link>
    </div>
  );
};

export default Cart;
