import React from "react";

export const SignFormSuccess = () => {
  return (
    <div className="container">
      <div className="app-wrapper">
        <h1
          style={{
            justifyContent: "center",
            textAlign: "center",
            marginTop: "150px",
          }}
        >
          Submitted Successfully!
        </h1>
      </div>
    </div>
  );
};
